$(function() {
	$("#includeMenu").load("menuPart.html");
});
